/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *	Version : java 1.5.0_06
 **/
 
public class Numeral
{
	public static boolean isOperand(String o)
	{	
		boolean operand = true;
			for(int i = 0; i < o.length(); i++)
			{
				char c = o.charAt(i);
				if(!Character.isDigit(c))
				{
					operand = false;
					break;
				}	
			}
		return operand;
	}
	
	public static boolean isOperator(String o)
	{
		return(o.equals("+") || o.equals("*") || 
		       o.equals("-") || o.equals("/"));
	}
}