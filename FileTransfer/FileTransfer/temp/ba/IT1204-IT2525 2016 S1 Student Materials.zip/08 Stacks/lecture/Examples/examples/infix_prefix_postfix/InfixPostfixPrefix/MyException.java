/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *	Version : java 1.5.0_06
 **/
 
public class MyException extends Exception
{
	public MyException(String msg)
	{
		System.out.println(msg);
	}
}