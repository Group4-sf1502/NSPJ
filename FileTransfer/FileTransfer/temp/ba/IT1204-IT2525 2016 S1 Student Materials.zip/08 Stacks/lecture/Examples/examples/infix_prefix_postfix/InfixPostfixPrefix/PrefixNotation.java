/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *  Version : java 1.5.0_06
 **/

import java.util.*;

public class PrefixNotation
{
	private StackArray stack;
	
	private StringTokenizer st;
	
	private StringBuffer prefix = new StringBuffer();
	private String[] tokenOfArray = new String[50];
	
	private int topPtr;
	
	public PrefixNotation(String infix)
	{
		convert(infix);
	}
	
	public void convert(String infix)
	{
		stack = new StackArray();
			
		st = new StringTokenizer(infix);
		
		while(st.hasMoreElements())
		{
			String token = st.nextToken();
			tokenOfArray[topPtr++] = token;
		}
	
		while(topPtr > 0)
		{
			--topPtr;
			
			if(Numeral.isOperand(tokenOfArray[topPtr]))
			{
				toPostfix(tokenOfArray[topPtr]);
			}
			
			else if(Numeral.isOperator(tokenOfArray[topPtr]))
			{
				if(!stack.isEmpty())
				{
					if(Priority.icp(tokenOfArray[topPtr]) < Priority.isp(String.valueOf(stack.top())))
					{
						toPostfix(String.valueOf(stack.pop()));
					
						stack.push(tokenOfArray[topPtr]);
					}
					else if(Priority.icp(tokenOfArray[topPtr]) > Priority.isp(String.valueOf(stack.top())))
					{
						stack.push(tokenOfArray[topPtr]);
					}
				}
				else
				{
					stack.push(tokenOfArray[topPtr]);
				}
			}
		}
		
		if(topPtr == 0)
		{
			while(!stack.isEmpty())
			{
				toPostfix(String.valueOf(stack.pop()));	
			}
		}
	}
	
	//display
	public void toPostfix(String token)
	{	
		int offset = 0;
		prefix.insert(offset--,token.concat(" "));
	}
	
	public String prefixNotation()
	{
		return prefix.toString();
	}
}