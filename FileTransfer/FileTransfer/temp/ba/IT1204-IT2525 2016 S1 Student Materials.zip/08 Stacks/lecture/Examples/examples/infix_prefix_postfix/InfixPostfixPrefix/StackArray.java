/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *	Version : java 1.5.0_06
 **/
 
public class StackArray implements Stack
{
    private Object stack[];
    private int sizeIndex = 100;
    private int topPtr;
		
    public StackArray()
    {
        stack = new Object[sizeIndex];
    }
    
    public void push(Object stackItem)
    { 
        if(!isFull())
        {
        	stack[topPtr] = stackItem;
        	topPtr++;
        }     
    }
    
    public Object pop()
    {
    	Object x = null;
    	if(!isEmpty())
        {
            x = stack[--topPtr];
            stack[topPtr] = null;
        }
        return x;
    }
    
    public Object top()
    {	
    	Object ts = null;
        if(!isEmpty())
        {
        	ts = stack[topPtr - 1];
        }
        return ts;  
    }
    
    public boolean isEmpty()
    {
        return topPtr == 0;
    }
    
    public boolean isFull()
    {
		return topPtr == sizeIndex;	 	
    }
    
    public void clear()
    {
     	for(int i =0; i < sizeIndex; i++)
        {
            stack[i] = null;
			topPtr--;
        }
    }
        
	public boolean contains(Object stackItem)
	{
		 boolean contains = false;
		 if(!isEmpty())
		 {
		 	for(int i = 0; i < sizeIndex; i++)
			{
			 if(stack[i].equals(stackItem))
			 {
			 	contains = true;
				break;
			 }
			}
		 }
		 return contains;
	}
		
    public String toString()
    {
        StringBuffer display = new StringBuffer();
        
        display.append("{");
            for(int i = 0; i< sizeIndex; i++)
            {
                if(stack[i] != null)
                {
                    display.append(stack[i]);
                    if( i < topPtr - 1)
                    {
                        display.append(",");
                    }
                }
            }
        
        display.append("}");
        return display.toString();
    }
}
