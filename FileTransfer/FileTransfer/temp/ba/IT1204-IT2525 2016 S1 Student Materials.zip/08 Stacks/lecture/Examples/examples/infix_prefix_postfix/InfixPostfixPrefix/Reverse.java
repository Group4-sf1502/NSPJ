/*
 *Author		: Ryanilo Yba�ez
 *Date Created	: September 8,2006
 *Location		: In my house
 *Course		: Computer Science
 *Decription	: reverse ex. ryanilo ybanez - olinayr zenaby
 *
 **/

public class Reverse
{
	public StringBuffer rev;
	public String[]		arr;
	public int	  		len;
	public int			ptr;
	
	public String 		wrd;
	
	public Reverse(String word)
	{
		arr = new String[100];
		wrd = word;
		
		split(wrd);
	}
	
	public void split(String word)
	{
		int  offset    = 0;
		char space 	   = ' ';
		
		for(int i = 0; i < word.length() - 1; i++)
		{
			if(word.charAt(i) == space)
			{
				arr[ptr++] = word.substring(offset,i);
				offset = i;
			}
		}
		
		//last word to store into array
		arr[ptr++] = word.substring(offset,(word.length()));
	}
		
	public String reverse()
	{
		rev = new StringBuffer();
		
		for(int i = 0; i < ptr ; i++)
		{
			String token = arr[i].trim();
			len = token.length();
			
			while(len > 0)
			{
				rev.append(token.charAt(--len));
			}
			
			rev.insert(rev.length()," ");	
		}
		
		return rev.toString();
	}
	
	public static void main(String[] args)
	{
		Reverse p = new Reverse("pare");
		
		System.out.println(p.reverse());
		System.out.println("\n");

	
	}
}