/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *
 **/

import java.util.*;

public class PostfixEvaluator
{
	StackArray stack;
	StringTokenizer st;

	private int val1,val2;
	private int result;

	public PostfixEvaluator(String postfix)
	{
		stack = new StackArray();

		st = new StringTokenizer(postfix);

		while(st.hasMoreElements())
		{
			String token = st.nextToken();
			if(Numeral.isOperand(token))
			{
				stack.push(token);
			}
			else if(Numeral.isOperator(token))
			{
				if(token.equals("+"))
				{
					val1 = Integer.parseInt(stack.pop().toString());
					val2 = Integer.parseInt(stack.pop().toString());

					result = val1 + val2;

					stack.push(new Integer(result));
				}
				else if(token.equals("-"))
				{
					val1 = Integer.parseInt(stack.pop().toString());
					val2 = Integer.parseInt(stack.pop().toString());

					result = val2 - val1;

					stack.push(new Integer(result));
				}
				else if(token.equals("*"))
				{
					val1 = Integer.parseInt(stack.pop().toString());
					val2 = Integer.parseInt(stack.pop().toString());

					result = val1 * val2;

					stack.push(new Integer(result));
				}
				else if(token.equals("/"))
				{
					val1 = Integer.parseInt(stack.pop().toString());
					val2 = Integer.parseInt(stack.pop().toString());

					result = val2 / val1;

					stack.push(new Integer(result));
				}
			}
		}
	}

	public String getResult()
	{
		return String.valueOf(stack.top());
	}
}