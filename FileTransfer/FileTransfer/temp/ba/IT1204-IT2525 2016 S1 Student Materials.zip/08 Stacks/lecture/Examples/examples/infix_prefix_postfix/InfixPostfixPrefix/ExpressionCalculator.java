/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *	Version : java 1.5.0_06
 **/
 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ExpressionCalculator implements KeyListener
{
	private JFrame frame;
	private JLabel label;
	private JPanel boxLayout,panel0,panel1,panel2,panel3;
	private JTextField TxtInfix,TxtPostfix,TxtPrefix,TxtResult;
	
	private Font font;
		
	public ExpressionCalculator()
	{
		boxLayout = new JPanel();
		
		font = new Font("Serif",Font.BOLD,12);
		
		//For infix notation
		panel0 = new JPanel(new FlowLayout(FlowLayout.CENTER,5,0));
		panel0.add(label = new JLabel("Infix :"));
		panel0.add(TxtInfix = new JTextField("",15));
		
		label.setFont(font);
		
		label.setPreferredSize(new Dimension(49,16));
		label.setHorizontalAlignment(JLabel.RIGHT);
		
		//KeyListener
		TxtInfix.addKeyListener(this);
		
		//For postfix notation
		panel1 = new JPanel(new FlowLayout(FlowLayout.CENTER,5,0));
		panel1.add(label = new JLabel("Postfix :"));
		panel1.add(TxtPostfix = new JTextField("",15));
		
		label.setFont(font);
		label.setPreferredSize(new Dimension(49,16));
		label.setHorizontalAlignment(JLabel.RIGHT);
		
		TxtPostfix.addKeyListener(this);
		
		//For the result of postfix evaluatro
		panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER,5,0));
		panel2.add(label = new JLabel("Prefix :"));
		panel2.add(TxtPrefix = new JTextField("",15));
		
		label.setFont(font);
		label.setPreferredSize(new Dimension(49,16));
		label.setHorizontalAlignment(JLabel.RIGHT);
		
		panel3 = new JPanel(new FlowLayout(FlowLayout.CENTER,5,0));
		panel3.add(label = new JLabel("Result :"));
		panel3.add(TxtResult = new JTextField("",15));
		
		label.setFont(font);
		label.setForeground(Color.RED);
		label.setPreferredSize(new Dimension(49,16));
		label.setHorizontalAlignment(JLabel.RIGHT);
		
		TxtResult.setFocusable(false);
	}
	
	public Container createContent()
	{
		boxLayout.setLayout(new BoxLayout(boxLayout, 
								BoxLayout.PAGE_AXIS));
		
		boxLayout.setOpaque(true);
				  
		boxLayout.add(panel0);
		boxLayout.add(Box.createRigidArea(new Dimension(0,5)));
		boxLayout.add(panel1);
		boxLayout.add(Box.createRigidArea(new Dimension(0,5)));
		boxLayout.add(panel2);
		boxLayout.add(Box.createRigidArea(new Dimension(0,5)));
		boxLayout.add(panel3);
		boxLayout.add(Box.createRigidArea(new Dimension(0,5)));
	
		boxLayout.setBorder(BorderFactory.createTitledBorder("Notations"));
		
		JPanel layoutPanel = new JPanel();	
		
		layoutPanel.add(boxLayout);
		
		return layoutPanel;
	}
	
	public void keyPressed(KeyEvent e)
	{
		Object source = e.getSource();
		String keyText = e.getKeyText(e.getKeyCode());
		
		if(source.equals(TxtInfix))
		{
			if(keyText.equals("Enter"))
			{
				String notation;
			
				notation  = new String(TxtInfix.getText());
			
				PostfixNotation i;
				i = new PostfixNotation(notation);
			
				TxtPostfix.setText(i.postfixNotation());
				
				PrefixNotation n;
				n = new PrefixNotation(notation);
			
				TxtPrefix.setText(n.prefixNotation());
			
				PostfixEvaluator p; 
				p = new PostfixEvaluator(TxtPostfix.getText());
			
				TxtResult.setText(p.getResult());
			}
		}
		else if(source.equals(TxtPostfix))
		{
			if(keyText.equals("Enter"))
			{
				PostfixEvaluator p; 
				p = new PostfixEvaluator(TxtPostfix.getText());
			
				TxtResult.setText(p.getResult());	
			}
		}
	}
	
	public void keyReleased(KeyEvent e){}
	public void keyTyped(KeyEvent e){}
	
	public void showGUI()
	{
		
		frame = new JFrame("Expression Calculator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(createContent());
				
		frame.pack();
		frame.setVisible(true);
		frame.setResizable(false);		
	}
	
	public static void main(String[] args)
	{
		Runnable doRun = new Runnable(){
				public void run()
				{
					new ExpressionCalculator().showGUI();
				}
			};
		javax.swing.SwingUtilities.invokeLater(doRun);
	}
}