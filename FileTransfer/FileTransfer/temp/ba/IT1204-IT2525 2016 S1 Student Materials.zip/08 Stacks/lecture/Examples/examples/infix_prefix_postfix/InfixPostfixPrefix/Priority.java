/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *	Version : java 1.5.0_06
 **/
 
public class Priority
{
	public static int icp(String x)
	{
		int priority = 0;
		
		if(x.equals("+") || x.equals("-"))
		{
			priority = 1;
		}
		else if(x.equals("/") || x.equals("*"))
		{
			priority = 3;
		}
		
		return priority;
	}
	
	public static int isp(String x)
	{
		int priority = 0;
		
		if(x.equals("+") || x.equals("-"))
		{
			priority = 2;	
		}
		else if(x.equals("/") || x.equals("*"))
		{
			priority = 4;
		}
		
		return priority;
	}
}