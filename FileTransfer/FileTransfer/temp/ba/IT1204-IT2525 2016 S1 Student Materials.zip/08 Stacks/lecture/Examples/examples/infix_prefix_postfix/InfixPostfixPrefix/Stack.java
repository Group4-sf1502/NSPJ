/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *	Version : java 1.5.0_06
 **/
 
public interface Stack
{
	public void push(Object item);
  	public Object pop();
  	public Object top();
  	public boolean isEmpty();
  	public boolean isFull();
  	public void clear();  
}
