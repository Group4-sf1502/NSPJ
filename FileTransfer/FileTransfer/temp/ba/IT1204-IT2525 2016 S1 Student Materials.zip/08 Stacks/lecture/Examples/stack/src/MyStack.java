//========================================================
// Program:		MyStack.java (Activity 8.1)
// Description:	To test all the methods in the Stack API. 
// Author :		Phoon Lee Kien
//========================================================
//import java.io.*;
import java.util.*;

public class MyStack{
	public static void main(String[] args){
	
		Stack<String> stack = new Stack<String>();
		
		if (stack.empty())
			System.out.println("An empty stack is created.");
		
		stack.push("First push");
		stack.push("Second push");
		stack.push("Third push");

		if (!stack.empty())
			System.out.println("Stack contains elements.");
		else
			System.out.println("Stack is created.");
			
		String line2 = "Second push";
		System.out.println("line2 is " + 	
						stack.search(line2) + " from the top");
			
		System.out.println("The top element = " + stack.peek());
			
		while (!stack.empty())	
			System.out.println(stack.pop());
	
	}	
}
