/*
 *	Author	: Ryan Nilo A. Yba�ez
 *	Course	: BSCS - IV
 *  Version : java 1.5.0_06
 **/

import java.util.*;
import javax.swing.JOptionPane;

public class PostfixNotation
{
	private StackArray stack;
	private StringTokenizer st;
	private StringBuffer postfix = new StringBuffer();
		
	public PostfixNotation(String infix)
	{
		convert(infix);
	}
	
	public void convert(String infix)
	{
		stack = new StackArray();
				
		st = new StringTokenizer(infix);
		
		while(st.hasMoreElements())
		{
			String token = st.nextToken();
			
			if(Numeral.isOperand(token))
			{
				toPostfix(token);
			}
			
			else if(Numeral.isOperator(token))
			{
				 if(!stack.isEmpty())
				 {	
					if(Priority.icp(token) < Priority.isp(String.valueOf(stack.top())))
					{
						while(!stack.isEmpty())
						{
							toPostfix(String.valueOf(stack.pop()));
						}
					
						stack.push(token);
					}
					else if(Priority.icp(token) > Priority.isp(String.valueOf(stack.top())))
					{
						stack.push(token);
					}
				 }
				 else
				 {
					stack.push(token);
				 }
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Invalid");
				break;		
			}

			if(!st.hasMoreTokens())
			{
				while(!stack.isEmpty())
				{
					toPostfix(String.valueOf(stack.pop()));
				}
			}	
		}		
	}
	
	public void toPostfix(String token)
	{
		postfix.append(token);
		postfix.insert(postfix.length()," ");
	}
	
	public String postfixNotation()
	{
		return postfix.toString();
	}
}